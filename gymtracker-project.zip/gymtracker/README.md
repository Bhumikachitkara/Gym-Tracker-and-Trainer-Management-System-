# 🏋️ GymTracker — Gym & Trainer Management System

A full-stack Java Spring Boot application for managing gym members, trainers, and workout sessions.

---

## 📁 Project Structure

```
gymtracker/
├── pom.xml
├── sql/
│   └── schema.sql                         ← Run this first in MySQL
└── src/main/
    ├── java/com/gymtracker/
    │   ├── GymTrackerApplication.java     ← Entry point
    │   ├── config/
    │   │   ├── SecurityConfig.java        ← Spring Security setup
    │   │   └── DataInitializer.java       ← Seeds admin on first run
    │   ├── controller/
    │   │   ├── AuthController.java        ← Login page
    │   │   ├── DashboardController.java   ← Dashboard stats
    │   │   ├── MemberController.java      ← Member CRUD
    │   │   ├── TrainerController.java     ← Trainer CRUD
    │   │   └── WorkoutController.java     ← Workout CRUD
    │   ├── model/
    │   │   ├── Admin.java
    │   │   ├── Member.java
    │   │   ├── Trainer.java
    │   │   ├── Workout.java
    │   │   └── TrainerAssignment.java
    │   ├── repository/                    ← JPA repositories
    │   └── service/                       ← Business logic
    └── resources/
        ├── application.properties
        ├── static/
        │   ├── css/style.css
        │   └── js/app.js
        └── templates/
            ├── login.html
            ├── dashboard.html
            ├── layout.html
            ├── members/ (list, form, view)
            ├── trainers/ (list, form, view)
            └── workouts/ (list, form, history)
```

---

## ✅ Prerequisites

| Tool       | Version  |
|------------|----------|
| Java       | 17+      |
| Maven      | 3.8+     |
| MySQL      | 8.0+     |
| IDE        | IntelliJ IDEA or VS Code |

---

## 🚀 Setup & Run Instructions

### Step 1 — Set up MySQL Database

Open MySQL Workbench or terminal and run:

```sql
-- Option A: Run the full schema file
SOURCE /path/to/gymtracker/sql/schema.sql;

-- Option B: Just create the empty DB (Spring will create tables)
CREATE DATABASE gymtracker_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### Step 2 — Configure database credentials

Edit `src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/gymtracker_db?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
spring.datasource.username=root        ← Change to your MySQL username
spring.datasource.password=root        ← Change to your MySQL password
```

### Step 3A — Run in IntelliJ IDEA

1. Open IntelliJ IDEA → **File → Open** → select the `gymtracker` folder
2. Wait for Maven to download dependencies (bottom progress bar)
3. Open `GymTrackerApplication.java`
4. Click the green ▶ **Run** button (or press `Shift+F10`)
5. Visit: **http://localhost:8080**

### Step 3B — Run in VS Code

1. Install extensions: **Extension Pack for Java** + **Spring Boot Extension Pack**
2. Open VS Code → **File → Open Folder** → select `gymtracker`
3. Open `GymTrackerApplication.java`
4. Click **Run** above the `main` method
5. Visit: **http://localhost:8080**

### Step 3C — Run via Terminal (Maven)

```bash
cd gymtracker
mvn spring-boot:run
```

Or build and run the JAR:

```bash
mvn clean package -DskipTests
java -jar target/gym-tracker-1.0.0.jar
```

---

## 🔐 Login Credentials

| Username | Password  |
|----------|-----------|
| `admin`  | `admin123`|

> The admin account is auto-created on first startup by `DataInitializer.java`

---

## 🌐 Application URLs

| Page              | URL                          |
|-------------------|------------------------------|
| Login             | http://localhost:8080/login  |
| Dashboard         | http://localhost:8080/dashboard |
| Members           | http://localhost:8080/members |
| Add Member        | http://localhost:8080/members/new |
| Trainers          | http://localhost:8080/trainers |
| Add Trainer       | http://localhost:8080/trainers/new |
| Workouts          | http://localhost:8080/workouts |
| Log Workout       | http://localhost:8080/workouts/new |

---

## 🗃️ Database Tables

| Table                | Description                        |
|---------------------|------------------------------------|
| `admins`            | Admin login credentials (BCrypt)   |
| `members`           | Gym member details                 |
| `trainers`          | Trainer details and specializations |
| `workouts`          | Per-member exercise session logs   |
| `trainer_assignments` | Many-to-many trainer ↔ member    |

---

## 🔑 Features

- **Secure Login** — Spring Security + BCrypt password hashing
- **Dashboard** — Live stats cards + Chart.js bar chart + quick actions
- **Member Management** — Full CRUD with search, filter by status/plan
- **Trainer Management** — Card-view grid, specialization tags
- **Workout Tracking** — Log exercise type, duration, calories; view history per member
- **Responsive UI** — Works on mobile, tablet, desktop
- **Search & Filter** — Server-side filtering on all list pages
- **Validation** — Bean Validation (JSR-380) on all forms
- **Flash Messages** — Success/error alerts auto-dismiss after 4 seconds
- **Animations** — Staggered card/row reveals, counter animations

---

## ⚙️ Tech Stack

| Layer      | Technology                            |
|------------|---------------------------------------|
| Backend    | Java 17, Spring Boot 3.2              |
| Security   | Spring Security 6, BCrypt             |
| ORM        | Hibernate / Spring Data JPA           |
| Database   | MySQL 8                               |
| Templates  | Thymeleaf 3                           |
| Frontend   | Bootstrap 5, Chart.js 4, Bootstrap Icons |
| Build      | Maven 3                               |

---

## 🐛 Troubleshooting

**"Access denied for user 'root'@'localhost'"**
→ Update username/password in `application.properties`

**"Communications link failure"**
→ Make sure MySQL is running: `sudo service mysql start`

**Port 8080 already in use**
→ Change port in `application.properties`: `server.port=8090`

**Thymeleaf template errors**
→ Make sure Lombok annotation processing is enabled in your IDE
