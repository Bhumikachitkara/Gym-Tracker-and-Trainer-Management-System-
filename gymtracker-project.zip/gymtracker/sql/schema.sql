-- ============================================================
-- GymTracker Database Schema
-- Run this script in MySQL before starting the application
-- ============================================================

-- Create database
CREATE DATABASE IF NOT EXISTS gymtracker_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE gymtracker_db;

-- ============================================================
-- TABLE: admins
-- Stores admin login credentials
-- ============================================================
CREATE TABLE IF NOT EXISTS admins (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    username    VARCHAR(100) NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,  -- BCrypt hashed
    email       VARCHAR(150),
    full_name   VARCHAR(150),
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- TABLE: trainers
-- Stores trainer information
-- ============================================================
CREATE TABLE IF NOT EXISTS trainers (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    full_name       VARCHAR(150) NOT NULL,
    email           VARCHAR(150) UNIQUE,
    phone           VARCHAR(20),
    specialization  VARCHAR(100),
    experience_years INT DEFAULT 0,
    salary          DECIMAL(10,2),
    status          ENUM('ACTIVE','INACTIVE') DEFAULT 'ACTIVE',
    joined_date     DATE,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- TABLE: members
-- Stores gym member information
-- ============================================================
CREATE TABLE IF NOT EXISTS members (
    id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
    full_name           VARCHAR(150) NOT NULL,
    email               VARCHAR(150) UNIQUE,
    phone               VARCHAR(20),
    age                 INT,
    gender              ENUM('MALE','FEMALE','OTHER'),
    address             TEXT,
    membership_plan     ENUM('BASIC','STANDARD','PREMIUM') DEFAULT 'BASIC',
    membership_status   ENUM('ACTIVE','EXPIRED','SUSPENDED') DEFAULT 'ACTIVE',
    join_date           DATE,
    expiry_date         DATE,
    trainer_id          BIGINT,
    created_at          DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_member_trainer FOREIGN KEY (trainer_id)
        REFERENCES trainers(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================================
-- TABLE: workouts
-- Logs exercise sessions for each member
-- ============================================================
CREATE TABLE IF NOT EXISTS workouts (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    member_id       BIGINT NOT NULL,
    exercise_type   VARCHAR(100) NOT NULL,
    duration_mins   INT NOT NULL,           -- Duration in minutes
    calories_burned INT,
    workout_date    DATE NOT NULL,
    notes           TEXT,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_workout_member FOREIGN KEY (member_id)
        REFERENCES members(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- TABLE: trainer_assignments
-- Many-to-many relationship between trainers and members
-- (Supplementary to the trainer_id FK on members table)
-- ============================================================
CREATE TABLE IF NOT EXISTS trainer_assignments (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    trainer_id      BIGINT NOT NULL,
    member_id       BIGINT NOT NULL,
    assigned_date   DATE,
    notes           TEXT,
    CONSTRAINT fk_assign_trainer FOREIGN KEY (trainer_id)
        REFERENCES trainers(id) ON DELETE CASCADE,
    CONSTRAINT fk_assign_member FOREIGN KEY (member_id)
        REFERENCES members(id) ON DELETE CASCADE,
    UNIQUE KEY uq_trainer_member (trainer_id, member_id)
) ENGINE=InnoDB;

-- ============================================================
-- INDEXES for performance
-- ============================================================
CREATE INDEX idx_member_status  ON members(membership_status);
CREATE INDEX idx_workout_date   ON workouts(workout_date);
CREATE INDEX idx_workout_member ON workouts(member_id);

-- ============================================================
-- SAMPLE DATA
-- ============================================================

-- Admin user (password: admin123 — BCrypt hash)
INSERT INTO admins (username, password, email, full_name) VALUES
('admin', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'admin@gymtracker.com', 'System Administrator');

-- Trainers
INSERT INTO trainers (full_name, email, phone, specialization, experience_years, salary, status, joined_date) VALUES
('Raj Kumar',     'raj.kumar@gym.com',    '9876543210', 'Strength & Conditioning', 8, 55000.00, 'ACTIVE', '2020-01-15'),
('Priya Sharma',  'priya.s@gym.com',      '9876543211', 'Yoga & Flexibility',      5, 45000.00, 'ACTIVE', '2021-03-01'),
('Amit Verma',    'amit.v@gym.com',       '9876543212', 'Cardio & Weight Loss',    6, 50000.00, 'ACTIVE', '2020-07-20'),
('Sunita Nair',   'sunita.n@gym.com',     '9876543213', 'Pilates & Core',          4, 42000.00, 'ACTIVE', '2022-01-10'),
('Vikram Singh',  'vikram.s@gym.com',     '9876543214', 'CrossFit & HIIT',         7, 52000.00, 'ACTIVE', '2019-11-05');

-- Members
INSERT INTO members (full_name, email, phone, age, gender, address, membership_plan, membership_status, join_date, expiry_date, trainer_id) VALUES
('Arjun Mehta',     'arjun.m@email.com',   '9811111111', 25, 'MALE',   'Sector 12, Panipat',    'PREMIUM',  'ACTIVE',  '2024-01-01', '2025-01-01', 1),
('Neha Gupta',      'neha.g@email.com',    '9811111112', 30, 'FEMALE', 'Model Town, Panipat',   'STANDARD', 'ACTIVE',  '2024-02-01', '2025-02-01', 2),
('Rohit Sharma',    'rohit.s@email.com',   '9811111113', 22, 'MALE',   'Old Court Road, Karnal','BASIC',    'ACTIVE',  '2024-03-01', '2025-03-01', 3),
('Anita Singh',     'anita.s@email.com',   '9811111114', 28, 'FEMALE', 'Sec 18, Kurukshetra',   'PREMIUM',  'ACTIVE',  '2024-01-15', '2025-01-15', 4),
('Mohit Yadav',     'mohit.y@email.com',   '9811111115', 35, 'MALE',   'Rohtak Road, Panipat',  'STANDARD', 'EXPIRED', '2023-05-01', '2024-05-01', 1),
('Pooja Patel',     'pooja.p@email.com',   '9811111116', 27, 'FEMALE', 'Sec 7, Panipat',        'PREMIUM',  'ACTIVE',  '2024-04-01', '2025-04-01', 5),
('Suresh Kumar',    'suresh.k@email.com',  '9811111117', 40, 'MALE',   'GT Road, Karnal',       'BASIC',    'ACTIVE',  '2024-05-01', '2025-05-01', 3),
('Kavita Joshi',    'kavita.j@email.com',  '9811111118', 32, 'FEMALE', 'New Colony, Panipat',   'STANDARD', 'ACTIVE',  '2024-06-01', '2025-06-01', 2),
('Deepak Tyagi',    'deepak.t@email.com',  '9811111119', 29, 'MALE',   'Sector 25, Panipat',    'PREMIUM',  'ACTIVE',  '2024-02-15', '2025-02-15', 1),
('Swati Agarwal',   'swati.a@email.com',   '9811111120', 24, 'FEMALE', 'Abrol Nagar, Panipat',  'BASIC',    'SUSPENDED','2024-01-20', '2025-01-20', 4);

-- Workouts
INSERT INTO workouts (member_id, exercise_type, duration_mins, calories_burned, workout_date, notes) VALUES
(1, 'Weight Training',  60, 450, '2025-01-01', 'Bench press, Deadlift, Squats'),
(1, 'Cardio Running',   45, 380, '2025-01-03', 'Treadmill interval training'),
(1, 'HIIT',            30, 350, '2025-01-05', 'High intensity circuit'),
(2, 'Yoga',            60, 200, '2025-01-02', 'Hatha yoga session'),
(2, 'Pilates',         45, 220, '2025-01-04', 'Core strengthening'),
(3, 'Cycling',         45, 400, '2025-01-01', 'Stationary bike'),
(3, 'Weight Training', 50, 420, '2025-01-03', 'Upper body day'),
(4, 'Zumba',          60, 500, '2025-01-02', 'Dance fitness class'),
(4, 'Weight Training', 55, 440, '2025-01-04', 'Lower body focus'),
(5, 'Cardio Running',  40, 320, '2025-01-01', 'Outdoor run'),
(6, 'CrossFit',        45, 600, '2025-01-03', 'WOD - Murph variant'),
(6, 'HIIT',           30, 380, '2025-01-05', 'Tabata training'),
(7, 'Swimming',        60, 480, '2025-01-02', 'Laps in pool'),
(8, 'Yoga',           45, 180, '2025-01-04', 'Yin yoga'),
(9, 'Strength',        70, 520, '2025-01-01', 'Power lifting session'),
(9, 'Cardio',          35, 300, '2025-01-03', 'Rowing machine'),
(10,'Pilates',         45, 210, '2025-01-02', 'Beginner pilates');

-- Trainer Assignments
INSERT INTO trainer_assignments (trainer_id, member_id, assigned_date, notes) VALUES
(1, 1, '2024-01-01', 'Primary trainer for strength program'),
(2, 2, '2024-02-01', 'Yoga and flexibility focus'),
(3, 3, '2024-03-01', 'Weight loss program'),
(4, 4, '2024-01-15', 'Core and posture improvement'),
(5, 6, '2024-04-01', 'CrossFit training program'),
(1, 9, '2024-02-15', 'Advanced strength training');
