package com.gymtracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * GymTrackerApplication — Entry point for the Spring Boot application.
 *
 * @SpringBootApplication enables:
 *   - @Configuration       : marks class as a configuration source
 *   - @EnableAutoConfiguration : Spring Boot's auto-config magic
 *   - @ComponentScan       : scans this package and sub-packages
 */
@SpringBootApplication
public class GymTrackerApplication {

    public static void main(String[] args) {
        SpringApplication.run(GymTrackerApplication.class, args);
        System.out.println("╔══════════════════════════════════════╗");
        System.out.println("║   GymTracker started successfully!   ║");
        System.out.println("║   Visit: http://localhost:8080       ║");
        System.out.println("╚══════════════════════════════════════╝");
    }
}
