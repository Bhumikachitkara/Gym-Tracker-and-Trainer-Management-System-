package com.gymtracker.config;

import com.gymtracker.model.Admin;
import com.gymtracker.repository.AdminRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * DataInitializer — runs at startup to ensure at least one admin exists.
 * If the "admin" user is not in the database, it creates one.
 *
 * Default credentials: admin / admin123
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final AdminRepository adminRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        // Only create if no admin exists
        if (!adminRepository.existsByUsername("admin")) {
            Admin admin = new Admin();
            admin.setUsername("admin");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setEmail("admin@gymtracker.com");
            admin.setFullName("System Administrator");
            adminRepository.save(admin);
            log.info("✅ Default admin created — username: admin | password: admin123");
        } else {
            log.info("✅ Admin account already exists, skipping seed.");
        }
    }
}
