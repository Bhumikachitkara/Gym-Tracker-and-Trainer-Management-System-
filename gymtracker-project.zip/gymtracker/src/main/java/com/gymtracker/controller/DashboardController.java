package com.gymtracker.controller;

import com.gymtracker.service.MemberService;
import com.gymtracker.service.TrainerService;
import com.gymtracker.service.WorkoutService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalDate;
import java.util.List;

/**
 * DashboardController — renders the main dashboard page with stats and charts.
 */
@Controller
@RequiredArgsConstructor
public class DashboardController {

    private final MemberService  memberService;
    private final TrainerService trainerService;
    private final WorkoutService workoutService;

    /**
     * GET /  → redirect to dashboard
     */
    @GetMapping("/")
    public String home() {
        return "redirect:/dashboard";
    }

    /**
     * GET /dashboard → main dashboard view with statistics.
     */
    @GetMapping("/dashboard")
    public String dashboard(Model model) {

        // ── Stat cards ─────────────────────────────────────────────
        model.addAttribute("totalMembers",       memberService.countAll());
        model.addAttribute("activeMembers",      memberService.countActiveMembers());
        model.addAttribute("totalTrainers",      trainerService.countAll());
        model.addAttribute("activeTrainers",     trainerService.countActiveTrainers());
        model.addAttribute("totalWorkouts",      workoutService.countAll());
        model.addAttribute("workoutsThisMonth",  workoutService.countThisMonth());

        // ── Recent workouts (last 5) ────────────────────────────────
        List<?> recentWorkouts = workoutService.getAllWorkouts();
        model.addAttribute("recentWorkouts",
                recentWorkouts.size() > 5 ? recentWorkouts.subList(0, 5) : recentWorkouts);

        // ── Monthly chart data (last 6 months) ─────────────────────
        List<Object[]> monthlyData = workoutService.getMonthlyWorkoutCounts();
        StringBuilder chartLabels = new StringBuilder("[");
        StringBuilder chartValues = new StringBuilder("[");
        String[] monthNames = {"Jan","Feb","Mar","Apr","May","Jun",
                               "Jul","Aug","Sep","Oct","Nov","Dec"};
        for (int i = 0; i < monthlyData.size(); i++) {
            Object[] row = monthlyData.get(i);
            int monthIdx = ((Number) row[0]).intValue() - 1;
            chartLabels.append("'").append(monthNames[monthIdx]).append("'");
            chartValues.append(row[1]);
            if (i < monthlyData.size() - 1) {
                chartLabels.append(",");
                chartValues.append(",");
            }
        }
        chartLabels.append("]");
        chartValues.append("]");

        model.addAttribute("chartLabels", chartLabels.toString());
        model.addAttribute("chartValues", chartValues.toString());

        // ── Top members (all, used for table) ──────────────────────
        model.addAttribute("members",  memberService.getAllMembers());
        model.addAttribute("trainers", trainerService.getAllTrainers());
        model.addAttribute("currentYear", LocalDate.now().getYear());

        return "dashboard";
    }
}
