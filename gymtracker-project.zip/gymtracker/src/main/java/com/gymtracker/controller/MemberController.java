package com.gymtracker.controller;

import com.gymtracker.model.Member;
import com.gymtracker.service.MemberService;
import com.gymtracker.service.TrainerService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * MemberController — handles all CRUD operations for Members via web UI.
 */
@Controller
@RequestMapping("/members")
@RequiredArgsConstructor
public class MemberController {

    private final MemberService  memberService;
    private final TrainerService trainerService;

    // ── LIST ────────────────────────────────────────────────────────────

    /**
     * GET /members — list all members, with optional search/filter.
     */
    @GetMapping
    public String listMembers(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String plan,
            Model model) {

        var members = (search != null && !search.isBlank())
                ? memberService.searchMembers(search)
                : (status != null && !status.isBlank())
                    ? memberService.getMembersByStatus(Member.MembershipStatus.valueOf(status))
                    : (plan != null && !plan.isBlank())
                        ? memberService.getMembersByPlan(Member.MembershipPlan.valueOf(plan))
                        : memberService.getAllMembers();

        model.addAttribute("members",  members);
        model.addAttribute("search",   search);
        model.addAttribute("status",   status);
        model.addAttribute("plan",     plan);
        model.addAttribute("statuses", Member.MembershipStatus.values());
        model.addAttribute("plans",    Member.MembershipPlan.values());
        return "members/list";
    }

    // ── CREATE ──────────────────────────────────────────────────────────

    /** GET /members/new — show add-member form */
    @GetMapping("/new")
    public String showAddForm(Model model) {
        model.addAttribute("member",   new Member());
        model.addAttribute("trainers", trainerService.getActiveTrainers());
        model.addAttribute("genders",  Member.Gender.values());
        model.addAttribute("plans",    Member.MembershipPlan.values());
        model.addAttribute("statuses", Member.MembershipStatus.values());
        model.addAttribute("pageTitle","Add New Member");
        return "members/form";
    }

    /** POST /members — persist new member */
    @PostMapping
    public String saveMember(
            @Valid @ModelAttribute("member") Member member,
            BindingResult result,
            @RequestParam(required = false) Long trainerId,
            Model model,
            RedirectAttributes redirectAttrs) {

        if (result.hasErrors()) {
            model.addAttribute("trainers", trainerService.getActiveTrainers());
            model.addAttribute("genders",  Member.Gender.values());
            model.addAttribute("plans",    Member.MembershipPlan.values());
            model.addAttribute("statuses", Member.MembershipStatus.values());
            model.addAttribute("pageTitle","Add New Member");
            return "members/form";
        }

        memberService.saveMember(member, trainerId);
        redirectAttrs.addFlashAttribute("successMsg", "Member added successfully!");
        return "redirect:/members";
    }

    // ── EDIT ────────────────────────────────────────────────────────────

    /** GET /members/{id}/edit — show edit form pre-filled */
    @GetMapping("/{id}/edit")
    public String showEditForm(@PathVariable Long id, Model model) {
        Member member = memberService.getMemberById(id);
        model.addAttribute("member",   member);
        model.addAttribute("trainers", trainerService.getActiveTrainers());
        model.addAttribute("genders",  Member.Gender.values());
        model.addAttribute("plans",    Member.MembershipPlan.values());
        model.addAttribute("statuses", Member.MembershipStatus.values());
        model.addAttribute("pageTitle","Edit Member");
        model.addAttribute("selectedTrainerId",
                member.getTrainer() != null ? member.getTrainer().getId() : null);
        return "members/form";
    }

    /** POST /members/{id}/edit — update existing member */
    @PostMapping("/{id}/edit")
    public String updateMember(
            @PathVariable Long id,
            @Valid @ModelAttribute("member") Member member,
            BindingResult result,
            @RequestParam(required = false) Long trainerId,
            Model model,
            RedirectAttributes redirectAttrs) {

        if (result.hasErrors()) {
            model.addAttribute("trainers", trainerService.getActiveTrainers());
            model.addAttribute("genders",  Member.Gender.values());
            model.addAttribute("plans",    Member.MembershipPlan.values());
            model.addAttribute("statuses", Member.MembershipStatus.values());
            model.addAttribute("pageTitle","Edit Member");
            return "members/form";
        }

        memberService.updateMember(id, member, trainerId);
        redirectAttrs.addFlashAttribute("successMsg", "Member updated successfully!");
        return "redirect:/members";
    }

    // ── DELETE ──────────────────────────────────────────────────────────

    /** POST /members/{id}/delete — delete a member */
    @PostMapping("/{id}/delete")
    public String deleteMember(@PathVariable Long id, RedirectAttributes redirectAttrs) {
        try {
            memberService.deleteMember(id);
            redirectAttrs.addFlashAttribute("successMsg", "Member deleted successfully.");
        } catch (Exception e) {
            redirectAttrs.addFlashAttribute("errorMsg", "Error deleting member: " + e.getMessage());
        }
        return "redirect:/members";
    }

    // ── VIEW DETAIL ─────────────────────────────────────────────────────

    /** GET /members/{id} — view member detail with workout history */
    @GetMapping("/{id}")
    public String viewMember(@PathVariable Long id, Model model) {
        model.addAttribute("member", memberService.getMemberById(id));
        return "members/view";
    }
}
