package com.gymtracker.controller;

import com.gymtracker.model.Trainer;
import com.gymtracker.service.TrainerService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * TrainerController — handles all CRUD operations for Trainers via web UI.
 */
@Controller
@RequestMapping("/trainers")
@RequiredArgsConstructor
public class TrainerController {

    private final TrainerService trainerService;

    // ── LIST ────────────────────────────────────────────────────────────

    @GetMapping
    public String listTrainers(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String status,
            Model model) {

        var trainers = (search != null && !search.isBlank())
                ? trainerService.searchTrainers(search)
                : (status != null && !status.isBlank())
                    ? trainerService.getAllTrainers().stream()
                        .filter(t -> t.getStatus().name().equals(status)).toList()
                    : trainerService.getAllTrainers();

        model.addAttribute("trainers", trainers);
        model.addAttribute("search",   search);
        model.addAttribute("status",   status);
        model.addAttribute("statuses", Trainer.TrainerStatus.values());
        return "trainers/list";
    }

    // ── CREATE ──────────────────────────────────────────────────────────

    @GetMapping("/new")
    public String showAddForm(Model model) {
        model.addAttribute("trainer",   new Trainer());
        model.addAttribute("statuses",  Trainer.TrainerStatus.values());
        model.addAttribute("pageTitle", "Add New Trainer");
        return "trainers/form";
    }

    @PostMapping
    public String saveTrainer(
            @Valid @ModelAttribute("trainer") Trainer trainer,
            BindingResult result,
            Model model,
            RedirectAttributes redirectAttrs) {

        if (result.hasErrors()) {
            model.addAttribute("statuses",  Trainer.TrainerStatus.values());
            model.addAttribute("pageTitle", "Add New Trainer");
            return "trainers/form";
        }

        trainerService.saveTrainer(trainer);
        redirectAttrs.addFlashAttribute("successMsg", "Trainer added successfully!");
        return "redirect:/trainers";
    }

    // ── EDIT ────────────────────────────────────────────────────────────

    @GetMapping("/{id}/edit")
    public String showEditForm(@PathVariable Long id, Model model) {
        model.addAttribute("trainer",   trainerService.getTrainerById(id));
        model.addAttribute("statuses",  Trainer.TrainerStatus.values());
        model.addAttribute("pageTitle", "Edit Trainer");
        return "trainers/form";
    }

    @PostMapping("/{id}/edit")
    public String updateTrainer(
            @PathVariable Long id,
            @Valid @ModelAttribute("trainer") Trainer trainer,
            BindingResult result,
            Model model,
            RedirectAttributes redirectAttrs) {

        if (result.hasErrors()) {
            model.addAttribute("statuses",  Trainer.TrainerStatus.values());
            model.addAttribute("pageTitle", "Edit Trainer");
            return "trainers/form";
        }

        trainerService.updateTrainer(id, trainer);
        redirectAttrs.addFlashAttribute("successMsg", "Trainer updated successfully!");
        return "redirect:/trainers";
    }

    // ── DELETE ──────────────────────────────────────────────────────────

    @PostMapping("/{id}/delete")
    public String deleteTrainer(@PathVariable Long id, RedirectAttributes redirectAttrs) {
        try {
            trainerService.deleteTrainer(id);
            redirectAttrs.addFlashAttribute("successMsg", "Trainer deleted successfully.");
        } catch (Exception e) {
            redirectAttrs.addFlashAttribute("errorMsg", "Cannot delete trainer with assigned members.");
        }
        return "redirect:/trainers";
    }

    // ── VIEW ─────────────────────────────────────────────────────────────

    @GetMapping("/{id}")
    public String viewTrainer(@PathVariable Long id, Model model) {
        Trainer trainer = trainerService.getTrainerById(id);
        model.addAttribute("trainer", trainer);
        return "trainers/view";
    }
}
