package com.gymtracker.controller;

import com.gymtracker.model.Workout;
import com.gymtracker.service.MemberService;
import com.gymtracker.service.WorkoutService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * WorkoutController — handles logging and viewing workout sessions.
 */
@Controller
@RequestMapping("/workouts")
@RequiredArgsConstructor
public class WorkoutController {

    private final WorkoutService workoutService;
    private final MemberService  memberService;

    // ── LIST ────────────────────────────────────────────────────────────

    /** GET /workouts — list all workouts, optionally filtered by member */
    @GetMapping
    public String listWorkouts(
            @RequestParam(required = false) Long memberId,
            Model model) {

        var workouts = (memberId != null)
                ? workoutService.getWorkoutsForMember(memberId)
                : workoutService.getAllWorkouts();

        model.addAttribute("workouts",       workouts);
        model.addAttribute("members",        memberService.getAllMembers());
        model.addAttribute("selectedMember", memberId);
        return "workouts/list";
    }

    // ── LOG NEW WORKOUT ──────────────────────────────────────────────────

    /** GET /workouts/new — show form to log a workout */
    @GetMapping("/new")
    public String showLogForm(
            @RequestParam(required = false) Long memberId,
            Model model) {
        Workout workout = new Workout();
        model.addAttribute("workout",   workout);
        model.addAttribute("members",   memberService.getAllMembers());
        model.addAttribute("memberId",  memberId);
        model.addAttribute("pageTitle", "Log Workout");
        return "workouts/form";
    }

    /** POST /workouts — save workout log */
    @PostMapping
    public String logWorkout(
            @Valid @ModelAttribute("workout") Workout workout,
            BindingResult result,
            @RequestParam Long memberId,
            Model model,
            RedirectAttributes redirectAttrs) {

        if (result.hasErrors()) {
            model.addAttribute("members",   memberService.getAllMembers());
            model.addAttribute("memberId",  memberId);
            model.addAttribute("pageTitle", "Log Workout");
            return "workouts/form";
        }

        workoutService.logWorkout(workout, memberId);
        redirectAttrs.addFlashAttribute("successMsg", "Workout logged successfully!");
        return "redirect:/workouts";
    }

    // ── EDIT ────────────────────────────────────────────────────────────

    @GetMapping("/{id}/edit")
    public String showEditForm(@PathVariable Long id, Model model) {
        Workout workout = workoutService.getWorkoutById(id);
        model.addAttribute("workout",   workout);
        model.addAttribute("members",   memberService.getAllMembers());
        model.addAttribute("memberId",  workout.getMember().getId());
        model.addAttribute("pageTitle", "Edit Workout");
        return "workouts/form";
    }

    @PostMapping("/{id}/edit")
    public String updateWorkout(
            @PathVariable Long id,
            @Valid @ModelAttribute("workout") Workout workout,
            BindingResult result,
            @RequestParam Long memberId,
            Model model,
            RedirectAttributes redirectAttrs) {

        if (result.hasErrors()) {
            model.addAttribute("members",   memberService.getAllMembers());
            model.addAttribute("memberId",  memberId);
            model.addAttribute("pageTitle", "Edit Workout");
            return "workouts/form";
        }

        workoutService.updateWorkout(id, workout);
        redirectAttrs.addFlashAttribute("successMsg", "Workout updated successfully!");
        return "redirect:/workouts";
    }

    // ── DELETE ──────────────────────────────────────────────────────────

    @PostMapping("/{id}/delete")
    public String deleteWorkout(@PathVariable Long id, RedirectAttributes redirectAttrs) {
        workoutService.deleteWorkout(id);
        redirectAttrs.addFlashAttribute("successMsg", "Workout deleted.");
        return "redirect:/workouts";
    }

    // ── MEMBER HISTORY ───────────────────────────────────────────────────

    /** GET /workouts/history/{memberId} — view progress history for one member */
    @GetMapping("/history/{memberId}")
    public String memberHistory(@PathVariable Long memberId, Model model) {
        model.addAttribute("member",        memberService.getMemberById(memberId));
        model.addAttribute("workouts",      workoutService.getWorkoutsForMember(memberId));
        model.addAttribute("totalCalories", workoutService.getTotalCaloriesForMember(memberId));
        return "workouts/history";
    }
}
