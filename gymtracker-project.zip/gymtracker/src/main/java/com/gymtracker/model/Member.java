package com.gymtracker.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Member entity — represents a gym member.
 * Each member belongs to an optional trainer
 * and can have many workout logs.
 */
@Entity
@Table(name = "members")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Member {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Full name is required")
    @Size(min = 2, max = 150, message = "Name must be 2–150 characters")
    @Column(name = "full_name", nullable = false, length = 150)
    private String fullName;

    @Email(message = "Invalid email format")
    @Column(length = 150, unique = true)
    private String email;

    @Pattern(regexp = "^[0-9]{10}$", message = "Phone must be a 10-digit number")
    @Column(length = 20)
    private String phone;

    @Min(value = 5, message = "Age must be at least 5")
    @Max(value = 120, message = "Age seems too high")
    private Integer age;

    @NotNull(message = "Gender is required")
    @Enumerated(EnumType.STRING)
    @Column(length = 10)
    private Gender gender;

    @Column(columnDefinition = "TEXT")
    private String address;

    @Enumerated(EnumType.STRING)
    @Column(name = "membership_plan", length = 10)
    private MembershipPlan membershipPlan = MembershipPlan.BASIC;

    @Enumerated(EnumType.STRING)
    @Column(name = "membership_status", length = 10)
    private MembershipStatus membershipStatus = MembershipStatus.ACTIVE;

    @Column(name = "join_date")
    private LocalDate joinDate;

    @Column(name = "expiry_date")
    private LocalDate expiryDate;

    // Many members can have one trainer (nullable)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "trainer_id")
    private Trainer trainer;

    // A member has many workout logs
    @OneToMany(mappedBy = "member", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Workout> workouts = new ArrayList<>();

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
    }

    // ── Enums ──────────────────────────────────────────────────────

    public enum Gender {
        MALE, FEMALE, OTHER
    }

    public enum MembershipPlan {
        BASIC, STANDARD, PREMIUM
    }

    public enum MembershipStatus {
        ACTIVE, EXPIRED, SUSPENDED
    }
}
