package com.gymtracker.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Trainer entity — stores information about gym trainers.
 * A trainer can be assigned to multiple members.
 */
@Entity
@Table(name = "trainers")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Trainer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Full name is required")
    @Size(min = 2, max = 150, message = "Name must be 2–150 characters")
    @Column(name = "full_name", nullable = false, length = 150)
    private String fullName;

    @Email(message = "Invalid email format")
    @Column(length = 150, unique = true)
    private String email;

    @Pattern(regexp = "^[0-9]{10}$", message = "Phone must be a 10-digit number")
    @Column(length = 20)
    private String phone;

    @Column(length = 100)
    private String specialization;

    @Min(value = 0, message = "Experience cannot be negative")
    @Max(value = 60, message = "Experience seems too high")
    @Column(name = "experience_years")
    private Integer experienceYears = 0;

    @DecimalMin(value = "0.0", inclusive = false, message = "Salary must be positive")
    @Column(precision = 10, scale = 2)
    private BigDecimal salary;

    @Enumerated(EnumType.STRING)
    @Column(length = 10)
    private TrainerStatus status = TrainerStatus.ACTIVE;

    @Column(name = "joined_date")
    private LocalDate joinedDate;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    // Bi-directional relationship with members
    @OneToMany(mappedBy = "trainer", fetch = FetchType.LAZY)
    private List<Member> members = new ArrayList<>();

    @PrePersist
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
    }

    /** Trainer status enum */
    public enum TrainerStatus {
        ACTIVE, INACTIVE
    }
}
