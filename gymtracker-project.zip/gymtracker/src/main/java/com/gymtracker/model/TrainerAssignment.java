package com.gymtracker.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * TrainerAssignment entity — represents a formal assignment
 * between a trainer and a member (many-to-many junction table).
 */
@Entity
@Table(
    name = "trainer_assignments",
    uniqueConstraints = @UniqueConstraint(columnNames = {"trainer_id", "member_id"})
)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrainerAssignment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "trainer_id", nullable = false)
    private Trainer trainer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "member_id", nullable = false)
    private Member member;

    @Column(name = "assigned_date")
    private LocalDate assignedDate;

    @Column(columnDefinition = "TEXT")
    private String notes;
}
