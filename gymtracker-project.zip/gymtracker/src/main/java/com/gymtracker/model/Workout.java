package com.gymtracker.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Workout entity — logs a single exercise session for a member.
 * Records exercise type, duration, calories burned, and date.
 */
@Entity
@Table(name = "workouts")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Workout {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Each workout belongs to exactly one member
    @NotNull(message = "Member is required")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "member_id", nullable = false)
    private Member member;

    @NotBlank(message = "Exercise type is required")
    @Size(max = 100, message = "Exercise type too long")
    @Column(name = "exercise_type", nullable = false, length = 100)
    private String exerciseType;

    @NotNull(message = "Duration is required")
    @Min(value = 1, message = "Duration must be at least 1 minute")
    @Max(value = 600, message = "Duration cannot exceed 600 minutes")
    @Column(name = "duration_mins", nullable = false)
    private Integer durationMins;

    @Min(value = 0, message = "Calories cannot be negative")
    @Column(name = "calories_burned")
    private Integer caloriesBurned;

    @NotNull(message = "Workout date is required")
    @Column(name = "workout_date", nullable = false)
    private LocalDate workoutDate;

    @Column(columnDefinition = "TEXT")
    private String notes;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
    }
}
