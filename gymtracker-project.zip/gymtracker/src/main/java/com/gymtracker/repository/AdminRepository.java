package com.gymtracker.repository;

import com.gymtracker.model.Admin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * AdminRepository — data access layer for Admin entity.
 * Spring Data JPA provides CRUD operations automatically.
 */
@Repository
public interface AdminRepository extends JpaRepository<Admin, Long> {

    /** Find admin by username (used during login) */
    Optional<Admin> findByUsername(String username);

    /** Check if a username already exists */
    boolean existsByUsername(String username);
}
