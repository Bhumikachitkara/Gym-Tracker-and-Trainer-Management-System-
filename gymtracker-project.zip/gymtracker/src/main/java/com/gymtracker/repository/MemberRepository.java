package com.gymtracker.repository;

import com.gymtracker.model.Member;
import com.gymtracker.model.Member.MembershipStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * MemberRepository — data access layer for Member entity.
 */
@Repository
public interface MemberRepository extends JpaRepository<Member, Long> {

    /** Find members by membership status */
    List<Member> findByMembershipStatus(MembershipStatus status);

    /** Find members assigned to a specific trainer */
    List<Member> findByTrainerId(Long trainerId);

    /** Count members by status */
    long countByMembershipStatus(MembershipStatus status);

    /**
     * Full-text search across name, email, phone, and plan.
     */
    @Query("SELECT m FROM Member m WHERE " +
           "LOWER(m.fullName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(m.email)    LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(m.phone)    LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Member> searchByKeyword(@Param("keyword") String keyword);

    /** Filter by membership plan */
    List<Member> findByMembershipPlan(Member.MembershipPlan plan);
}
