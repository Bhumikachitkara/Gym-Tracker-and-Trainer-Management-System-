package com.gymtracker.repository;

import com.gymtracker.model.TrainerAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * TrainerAssignmentRepository — data access for TrainerAssignment entity.
 */
@Repository
public interface TrainerAssignmentRepository extends JpaRepository<TrainerAssignment, Long> {

    /** All assignments for a trainer */
    List<TrainerAssignment> findByTrainerId(Long trainerId);

    /** All assignments for a member */
    List<TrainerAssignment> findByMemberId(Long memberId);

    /** Check if a specific trainer-member pair already exists */
    Optional<TrainerAssignment> findByTrainerIdAndMemberId(Long trainerId, Long memberId);

    /** Check for duplicate */
    boolean existsByTrainerIdAndMemberId(Long trainerId, Long memberId);
}
