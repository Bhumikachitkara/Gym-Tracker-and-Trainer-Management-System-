package com.gymtracker.repository;

import com.gymtracker.model.Trainer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * TrainerRepository — data access layer for Trainer entity.
 */
@Repository
public interface TrainerRepository extends JpaRepository<Trainer, Long> {

    /** Find all active trainers */
    List<Trainer> findByStatus(Trainer.TrainerStatus status);

    /** Search trainers by name or specialization (case-insensitive) */
    @Query("SELECT t FROM Trainer t WHERE " +
           "LOWER(t.fullName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(t.specialization) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Trainer> searchByKeyword(@Param("keyword") String keyword);

    /** Count active trainers */
    long countByStatus(Trainer.TrainerStatus status);
}
