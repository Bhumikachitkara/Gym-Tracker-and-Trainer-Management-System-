package com.gymtracker.repository;

import com.gymtracker.model.Workout;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * WorkoutRepository — data access layer for Workout entity.
 */
@Repository
public interface WorkoutRepository extends JpaRepository<Workout, Long> {

    /** Get all workouts for a specific member, newest first */
    List<Workout> findByMemberIdOrderByWorkoutDateDesc(Long memberId);

    /** Get workouts within a date range for a member */
    @Query("SELECT w FROM Workout w WHERE w.member.id = :memberId " +
           "AND w.workoutDate BETWEEN :startDate AND :endDate " +
           "ORDER BY w.workoutDate DESC")
    List<Workout> findByMemberAndDateRange(
            @Param("memberId")  Long memberId,
            @Param("startDate") LocalDate startDate,
            @Param("endDate")   LocalDate endDate
    );

    /** Total workouts this month (for dashboard) */
    @Query("SELECT COUNT(w) FROM Workout w WHERE " +
           "MONTH(w.workoutDate) = :month AND YEAR(w.workoutDate) = :year")
    long countByMonthAndYear(@Param("month") int month, @Param("year") int year);

    /** Total calories burned by a member */
    @Query("SELECT COALESCE(SUM(w.caloriesBurned), 0) FROM Workout w WHERE w.member.id = :memberId")
    int totalCaloriesByMember(@Param("memberId") Long memberId);

    /** Monthly workout counts for chart (last 6 months) */
    @Query(value = "SELECT MONTH(workout_date) as month, COUNT(*) as count " +
                   "FROM workouts WHERE workout_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) " +
                   "GROUP BY MONTH(workout_date) ORDER BY MONTH(workout_date)",
           nativeQuery = true)
    List<Object[]> getMonthlyWorkoutCounts();

    /** All workouts ordered by date descending (for global list) */
    List<Workout> findAllByOrderByWorkoutDateDesc();
}
