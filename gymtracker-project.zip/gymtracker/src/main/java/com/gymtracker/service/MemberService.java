package com.gymtracker.service;

import com.gymtracker.model.Member;
import com.gymtracker.model.Trainer;
import com.gymtracker.repository.MemberRepository;
import com.gymtracker.repository.TrainerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * MemberService — business logic for Member CRUD and queries.
 */
@Service
@RequiredArgsConstructor
@Transactional
public class MemberService {

    private final MemberRepository memberRepository;
    private final TrainerRepository trainerRepository;

    @Transactional(readOnly = true)
    public List<Member> getAllMembers() {
        return memberRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Member getMemberById(Long id) {
        return memberRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Member not found with id: " + id));
    }

    /** Save a new member; optionally assign a trainer by ID */
    public Member saveMember(Member member, Long trainerId) {
        if (trainerId != null) {
            Trainer trainer = trainerRepository.findById(trainerId)
                    .orElse(null);
            member.setTrainer(trainer);
        }
        return memberRepository.save(member);
    }

    /** Update member fields */
    public Member updateMember(Long id, Member updated, Long trainerId) {
        Member existing = getMemberById(id);
        existing.setFullName(updated.getFullName());
        existing.setEmail(updated.getEmail());
        existing.setPhone(updated.getPhone());
        existing.setAge(updated.getAge());
        existing.setGender(updated.getGender());
        existing.setAddress(updated.getAddress());
        existing.setMembershipPlan(updated.getMembershipPlan());
        existing.setMembershipStatus(updated.getMembershipStatus());
        existing.setJoinDate(updated.getJoinDate());
        existing.setExpiryDate(updated.getExpiryDate());

        if (trainerId != null) {
            Trainer trainer = trainerRepository.findById(trainerId).orElse(null);
            existing.setTrainer(trainer);
        } else {
            existing.setTrainer(null);
        }
        return memberRepository.save(existing);
    }

    public void deleteMember(Long id) {
        if (!memberRepository.existsById(id)) {
            throw new RuntimeException("Member not found with id: " + id);
        }
        memberRepository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public List<Member> searchMembers(String keyword) {
        if (keyword == null || keyword.isBlank()) return getAllMembers();
        return memberRepository.searchByKeyword(keyword);
    }

    @Transactional(readOnly = true)
    public List<Member> getMembersByStatus(Member.MembershipStatus status) {
        return memberRepository.findByMembershipStatus(status);
    }

    @Transactional(readOnly = true)
    public List<Member> getMembersByPlan(Member.MembershipPlan plan) {
        return memberRepository.findByMembershipPlan(plan);
    }

    @Transactional(readOnly = true)
    public long countActiveMembers() {
        return memberRepository.countByMembershipStatus(Member.MembershipStatus.ACTIVE);
    }

    @Transactional(readOnly = true)
    public long countAll() {
        return memberRepository.count();
    }
}
