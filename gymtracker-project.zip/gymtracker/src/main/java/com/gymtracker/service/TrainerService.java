package com.gymtracker.service;

import com.gymtracker.model.Trainer;
import com.gymtracker.repository.TrainerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * TrainerService — business logic layer for Trainer operations.
 */
@Service
@RequiredArgsConstructor
@Transactional
public class TrainerService {

    private final TrainerRepository trainerRepository;

    /** Retrieve all trainers */
    @Transactional(readOnly = true)
    public List<Trainer> getAllTrainers() {
        return trainerRepository.findAll();
    }

    /** Retrieve all ACTIVE trainers (for dropdowns) */
    @Transactional(readOnly = true)
    public List<Trainer> getActiveTrainers() {
        return trainerRepository.findByStatus(Trainer.TrainerStatus.ACTIVE);
    }

    /** Find trainer by ID, throws exception if not found */
    @Transactional(readOnly = true)
    public Trainer getTrainerById(Long id) {
        return trainerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Trainer not found with id: " + id));
    }

    /** Save a new trainer */
    public Trainer saveTrainer(Trainer trainer) {
        return trainerRepository.save(trainer);
    }

    /** Update an existing trainer */
    public Trainer updateTrainer(Long id, Trainer updated) {
        Trainer existing = getTrainerById(id);
        existing.setFullName(updated.getFullName());
        existing.setEmail(updated.getEmail());
        existing.setPhone(updated.getPhone());
        existing.setSpecialization(updated.getSpecialization());
        existing.setExperienceYears(updated.getExperienceYears());
        existing.setSalary(updated.getSalary());
        existing.setStatus(updated.getStatus());
        existing.setJoinedDate(updated.getJoinedDate());
        return trainerRepository.save(existing);
    }

    /** Delete trainer by ID */
    public void deleteTrainer(Long id) {
        if (!trainerRepository.existsById(id)) {
            throw new RuntimeException("Trainer not found with id: " + id);
        }
        trainerRepository.deleteById(id);
    }

    /** Search trainers by keyword */
    @Transactional(readOnly = true)
    public List<Trainer> searchTrainers(String keyword) {
        if (keyword == null || keyword.isBlank()) return getAllTrainers();
        return trainerRepository.searchByKeyword(keyword);
    }

    /** Count active trainers */
    @Transactional(readOnly = true)
    public long countActiveTrainers() {
        return trainerRepository.countByStatus(Trainer.TrainerStatus.ACTIVE);
    }

    /** Total count */
    @Transactional(readOnly = true)
    public long countAll() {
        return trainerRepository.count();
    }
}
