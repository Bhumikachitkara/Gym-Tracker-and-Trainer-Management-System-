package com.gymtracker.service;

import com.gymtracker.model.Member;
import com.gymtracker.model.Workout;
import com.gymtracker.repository.MemberRepository;
import com.gymtracker.repository.WorkoutRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

/**
 * WorkoutService — business logic for logging and querying workouts.
 */
@Service
@RequiredArgsConstructor
@Transactional
public class WorkoutService {

    private final WorkoutRepository workoutRepository;
    private final MemberRepository  memberRepository;

    @Transactional(readOnly = true)
    public List<Workout> getAllWorkouts() {
        return workoutRepository.findAllByOrderByWorkoutDateDesc();
    }

    @Transactional(readOnly = true)
    public Workout getWorkoutById(Long id) {
        return workoutRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Workout not found with id: " + id));
    }

    /** Log a new workout for a member */
    public Workout logWorkout(Workout workout, Long memberId) {
        Member member = memberRepository.findById(memberId)
                .orElseThrow(() -> new RuntimeException("Member not found with id: " + memberId));
        workout.setMember(member);
        return workoutRepository.save(workout);
    }

    /** Update workout details */
    public Workout updateWorkout(Long id, Workout updated) {
        Workout existing = getWorkoutById(id);
        existing.setExerciseType(updated.getExerciseType());
        existing.setDurationMins(updated.getDurationMins());
        existing.setCaloriesBurned(updated.getCaloriesBurned());
        existing.setWorkoutDate(updated.getWorkoutDate());
        existing.setNotes(updated.getNotes());
        return workoutRepository.save(existing);
    }

    public void deleteWorkout(Long id) {
        workoutRepository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public List<Workout> getWorkoutsForMember(Long memberId) {
        return workoutRepository.findByMemberIdOrderByWorkoutDateDesc(memberId);
    }

    @Transactional(readOnly = true)
    public List<Workout> getWorkoutsForMemberInRange(Long memberId, LocalDate start, LocalDate end) {
        return workoutRepository.findByMemberAndDateRange(memberId, start, end);
    }

    @Transactional(readOnly = true)
    public int getTotalCaloriesForMember(Long memberId) {
        return workoutRepository.totalCaloriesByMember(memberId);
    }

    @Transactional(readOnly = true)
    public long countAll() {
        return workoutRepository.count();
    }

    @Transactional(readOnly = true)
    public long countThisMonth() {
        LocalDate now = LocalDate.now();
        return workoutRepository.countByMonthAndYear(now.getMonthValue(), now.getYear());
    }

    @Transactional(readOnly = true)
    public List<Object[]> getMonthlyWorkoutCounts() {
        return workoutRepository.getMonthlyWorkoutCounts();
    }
}
