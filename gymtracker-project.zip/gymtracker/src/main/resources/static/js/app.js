/**
 * GymTracker — app.js
 * Sidebar toggle, animations, confirm dialogs, live search
 */
document.addEventListener('DOMContentLoaded', function () {

    // ── SIDEBAR TOGGLE (mobile) ────────────────────────────────
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');

    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', function () {
            sidebar.classList.toggle('open');
        });
        document.addEventListener('click', function (e) {
            if (window.innerWidth < 992 &&
                sidebar.classList.contains('open') &&
                !sidebar.contains(e.target) &&
                !sidebarToggle.contains(e.target)) {
                sidebar.classList.remove('open');
            }
        });
    }

    // ── AUTO-DISMISS ALERTS after 4s ──────────────────────────
    document.querySelectorAll('.alert-custom, .alert-dismissible').forEach(function (alert) {
        setTimeout(function () {
            alert.style.transition = 'opacity 0.5s ease';
            alert.style.opacity = '0';
            setTimeout(function () { alert.remove(); }, 500);
        }, 4000);
    });

    // ── STAT CARD COUNTER ANIMATION ───────────────────────────
    document.querySelectorAll('.stat-card__value').forEach(function (el) {
        const raw = el.textContent.trim();
        const target = parseFloat(raw.replace(/[^0-9.]/g, ''));
        if (isNaN(target) || target === 0) return;
        const isDecimal = raw.includes('.');
        const duration = 900, step = 16, steps = duration / step;
        const inc = target / steps;
        let current = 0;
        const timer = setInterval(function () {
            current += inc;
            if (current >= target) { current = target; clearInterval(timer); }
            el.textContent = isDecimal ? current.toFixed(1) : Math.floor(current).toString();
        }, step);
    });

    // ── FADE-IN PAGE ──────────────────────────────────────────
    const page = document.querySelector('.page-content');
    if (page) {
        page.style.opacity = '0';
        page.style.transform = 'translateY(10px)';
        page.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
        requestAnimationFrame(function () {
            page.style.opacity = '1';
            page.style.transform = 'translateY(0)';
        });
    }

    // ── STAGGER STAT CARDS ─────────────────────────────────────
    document.querySelectorAll('.stat-card').forEach(function (card, i) {
        card.style.opacity = '0';
        card.style.transform = 'translateY(16px)';
        card.style.transition = 'opacity 0.4s ease, transform 0.4s ease, box-shadow 0.2s ease';
        setTimeout(function () {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, i * 80);
    });

    // ── STAGGER TRAINER CARDS ─────────────────────────────────
    document.querySelectorAll('.trainer-card').forEach(function (card, i) {
        card.style.opacity = '0';
        card.style.transform = 'translateY(12px)';
        card.style.transition = 'opacity 0.35s ease, transform 0.35s ease, border-color 0.2s ease, box-shadow 0.2s ease';
        setTimeout(function () {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, i * 60);
    });

    // ── STAGGER TABLE ROWS ─────────────────────────────────────
    document.querySelectorAll('.data-table tbody tr').forEach(function (row, i) {
        row.style.opacity = '0';
        row.style.transform = 'translateX(-6px)';
        row.style.transition = 'opacity 0.3s ease, transform 0.3s ease, background 0.15s ease';
        setTimeout(function () {
            row.style.opacity = '1';
            row.style.transform = 'translateX(0)';
        }, 100 + i * 30);
    });

    // ── SPEC TAG CLICK-TO-FILL ─────────────────────────────────
    const specInput = document.querySelector('input[name="specialization"]');
    if (specInput) {
        document.querySelectorAll('.spec-tag').forEach(function (tag) {
            tag.addEventListener('click', function () {
                specInput.value = this.textContent.trim();
                specInput.focus();
                document.querySelectorAll('.spec-tag').forEach(t => {
                    t.style.background = '';
                    t.style.color = '';
                    t.style.borderColor = '';
                });
                this.style.background = 'rgba(255,107,53,0.2)';
                this.style.color = '#FF6B35';
                this.style.borderColor = 'rgba(255,107,53,0.5)';
            });
        });
    }

    // ── DEFAULT TODAY FOR EMPTY DATE INPUTS ────────────────────
    document.querySelectorAll('input[type="date"]').forEach(function (input) {
        if (!input.value) {
            input.value = new Date().toISOString().split('T')[0];
        }
    });

});

// Delete confirmation — called inline via onsubmit
function confirmDelete(name) {
    return confirm('Delete this ' + name + '? This cannot be undone.');
}
